const User = require("../models/userModel");
const Booking = require("../models/bookingModel");
const {
  sendVerificationCode,
  welcomeCode,
  sendTeacherPendingEmail,
  sendAdminTeacherNotification,
  sendTeacherApprovedEmail,
  sendTeacherRejectedEmail,
} = require("../middleware/email");
const { generateToken } = require("../middleware/jwt");

exports.register = async (req, res) => {
  try {
    const { name, email, password, phone, role } = req.body;

    if (!name || !email || !password || !phone || !role) {
      return res.status(400).json({ error: "All fields are required" });
    }

    if (!["student", "tutor"].includes(role)) {
      return res.status(400).json({ error: "Invalid role" });
    }

    // Teacher must upload cnic and experience letter
    if (role === "tutor") {
      if (!req.files?.cnic || !req.files?.experienceLetter) {
        return res
          .status(400)
          .json({
            error: "CNIC and experience letter are required for tutors",
          });
      }
    }

    const existEmail = await User.findOne({ email });
    if (existEmail) {
      return res.status(400).json({ error: "Email already exists" });
    }

    const verificationCode = Math.floor(
      100000 + Math.random() * 900000,
    ).toString();

    const userData = {
      name,
      email,
      password,
      phone,
      role,
      verificationCode,
    };

    // Optional profile picture (both roles)
    if (req.files?.profile?.[0]) {
      userData.profile = req.files.profile[0].path;
    }

    // Tutor documents
    if (role === "tutor") {
      userData.cnic = req.files.cnic[0].path;
      userData.experienceLetter = req.files.experienceLetter[0].path;
      userData.isApproved = false;
    }

    const user = new User(userData);
    await user.save();

    // Always send OTP to user
    await sendVerificationCode(email, verificationCode);

    // If tutor: send pending email to teacher + notify admin
    if (role === "tutor") {
      await sendTeacherPendingEmail(email, name);
      await sendAdminTeacherNotification({ name, email, phone });
    }

    res.status(200).json({
      message:
        role === "tutor"
          ? "Signup successful. Your account will be activated after admin approval."
          : "Signup successful. Check your email for verification code.",
    });
  } catch (err) {
    console.error("Signup Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password, role } = req.body;
    if (!email || !password || !role) {
      return res
        .status(400)
        .json({ error: "Email, password, and role are required" });
    }

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: "Invalid credentials" });

    if (!user.isVerified) {
      return res.status(400).json({ error: "Please verify your email first" });
    }

    if (user.role !== role) {
      return res.status(400).json({ error: "Invalid role selected" });
    }

    // Tutor must be approved by admin
    if (role === "tutor" && !user.isApproved) {
      return res
        .status(403)
        .json({ error: "Your account is pending admin approval" });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

    const token = generateToken({ id: user._id });

    res.status(200).json({
      message: "Login successful",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        profile: user.profile,
      },
    });
  } catch (err) {
    console.error("Login Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.verify = async (req, res) => {
  try {
    const { code } = req.body;
    if (!code)
      return res.status(400).json({ error: "Verification code is required" });

    const user = await User.findOne({ verificationCode: code.toString() });
    if (!user)
      return res.status(400).json({ error: "Invalid verification code" });

    user.isVerified = true;
    user.verificationCode = undefined;
    await user.save();

    await welcomeCode(user.email, user.name);

    res.status(200).json({ message: "Email verified successfully" });
  } catch (err) {
    console.error("Verification Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.forgot = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: "User not found" });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    user.resetPasswordOTP = otp;
    user.resetPasswordExpires = new Date(Date.now() + 10 * 60 * 1000);
    await user.save({ validateBeforeSave: false });

    await sendVerificationCode(email, otp);

    res.status(200).json({ message: "OTP sent to your email" });
  } catch (err) {
    console.error("Forgot Password Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.reset = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;
    if (!email || !otp || !newPassword) {
      return res
        .status(400)
        .json({ error: "Email, OTP, and new password are required" });
    }

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: "User not found" });

    if (!user.resetPasswordOTP || !user.resetPasswordExpires) {
      return res.status(400).json({ error: "OTP was not requested" });
    }
    if (user.resetPasswordOTP !== otp.toString()) {
      return res.status(400).json({ error: "Invalid OTP" });
    }
    if (user.resetPasswordExpires < new Date()) {
      return res.status(400).json({ error: "OTP has expired" });
    }

    user.password = newPassword;
    user.resetPasswordOTP = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    res.status(200).json({ message: "Password reset successful" });
  } catch (err) {
    console.error("Reset Password Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.loginData = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select(
      "-password -verificationCode -resetPasswordOTP -resetPasswordExpires",
    );
    if (!user) return res.status(404).json({ error: "User not found" });
    res.status(200).json(user);
  } catch (err) {
    console.error("Login Data Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

const publicTutorSelect =
  "name email phone profile subject experience rate qualification bio location tags available availabilitySlots isApproved isVerified createdAt";

exports.updateTutorProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });
    if (user.role !== "tutor") {
      return res.status(403).json({ error: "Only tutors can update tutor profile" });
    }

    const allowedFields = [
      "name",
      "phone",
      "subject",
      "experience",
      "rate",
      "qualification",
      "bio",
      "location",
    ];

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) user[field] = req.body[field];
    });

    if (req.body.tags !== undefined) {
      user.tags = Array.isArray(req.body.tags)
        ? req.body.tags
        : req.body.tags
            .split(",")
            .map((tag) => tag.trim())
            .filter(Boolean);
    }

    if (req.body.available !== undefined) {
      user.available = req.body.available === "true" || req.body.available === true;
    }

    if (req.file) {
      user.profile = req.file.path;
    }

    await user.save({ validateBeforeSave: false });

    const updatedUser = await User.findById(user._id).select(
      "-password -verificationCode -resetPasswordOTP -resetPasswordExpires",
    );

    res.status(200).json({
      message: "Profile updated successfully",
      user: updatedUser,
    });
  } catch (err) {
    console.error("Update Tutor Profile Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getPublicTutors = async (req, res) => {
  try {
    const tutors = await User.find({
      role: "tutor",
      isApproved: true,
      isVerified: true,
    })
      .select(publicTutorSelect)
      .sort({ updatedAt: -1 });

    const publicTutors = tutors.map((tutor) => {
      const tutorObject = tutor.toObject();
      tutorObject.availabilitySlots = (tutorObject.availabilitySlots || []).filter(
        (slot) => !slot.isBooked,
      );
      return tutorObject;
    });

    res.status(200).json(publicTutors);
  } catch (err) {
    console.error("Get Public Tutors Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.updateTutorAvailability = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });
    if (user.role !== "tutor") {
      return res.status(403).json({ error: "Only tutors can update availability" });
    }

    if (!Array.isArray(req.body.slots)) {
      return res.status(400).json({ error: "Slots must be an array" });
    }

    user.availabilitySlots = req.body.slots
      .filter((slot) => slot.day && slot.from && slot.to)
      .map((slot) => ({
        _id: slot._id,
        day: slot.day,
        from: slot.from,
        to: slot.to,
        isBooked: slot.isBooked === true,
      }));

    await user.save({ validateBeforeSave: false });

    res.status(200).json({
      message: "Availability updated successfully",
      availabilitySlots: user.availabilitySlots,
    });
  } catch (err) {
    console.error("Update Tutor Availability Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.bookTutorSlot = async (req, res) => {
  try {
    const { tutorId } = req.params;
    const { slotId } = req.body;

    if (!slotId) return res.status(400).json({ error: "Please select a slot" });

    const student = await User.findById(req.user.id);
    if (!student) return res.status(404).json({ error: "Student not found" });
    if (student.role !== "student") {
      return res.status(403).json({ error: "Only students can book tutor slots" });
    }

    const tutor = await User.findById(tutorId);
    if (!tutor || tutor.role !== "tutor" || !tutor.isApproved || !tutor.isVerified) {
      return res.status(404).json({ error: "Tutor not found" });
    }

    const slot = tutor.availabilitySlots.id(slotId);
    if (!slot) return res.status(404).json({ error: "Slot not found" });
    if (slot.isBooked) return res.status(400).json({ error: "This slot is already booked" });

    slot.isBooked = true;
    await tutor.save({ validateBeforeSave: false });

    const booking = await Booking.create({
      student: student._id,
      tutor: tutor._id,
      slotId: slot._id,
      day: slot.day,
      from: slot.from,
      to: slot.to,
      subject: tutor.subject,
      rate: tutor.rate,
    });

    res.status(201).json({
      message: "Slot booked successfully",
      booking,
      slotId: slot._id,
    });
  } catch (err) {
    console.error("Book Tutor Slot Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.approveTeacher = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });
    if (user.role !== "tutor")
      return res.status(400).json({ error: "User is not a tutor" });

    user.isApproved = true;
    user.isVerified = true;
    await user.save({ validateBeforeSave: false });

    await sendTeacherApprovedEmail(user.email, user.name);

    res.status(200).json({ message: "Teacher approved successfully" });
  } catch (err) {
    console.error("Approve Teacher Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.rejectTeacher = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });
    if (user.role !== "tutor")
      return res.status(400).json({ error: "User is not a tutor" });

    await sendTeacherRejectedEmail(user.email, user.name);
    await User.findByIdAndDelete(userId);

    res
      .status(200)
      .json({ message: "Teacher rejected and notified successfully" });
  } catch (err) {
    console.error("Reject Teacher Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

// ── Admin: Get Pending Tutors with documents ───────────────────────────────
exports.getPendingTutors = async (req, res) => {
  try {
    const tutors = await User.find({ role: "tutor" })
      .select(
        "-password -verificationCode -resetPasswordOTP -resetPasswordExpires",
      )
      .sort({ createdAt: -1 });
    res.status(200).json(tutors);
  } catch (err) {
    console.error("Get Pending Tutors Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find({ role: { $ne: "admin" } })
      .select(
        "-password -verificationCode -resetPasswordOTP -resetPasswordExpires -cnic -experienceLetter",
      )
      .sort({ createdAt: -1 });
    res.status(200).json(users);
  } catch (err) {
    console.error("Get All Users Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.toggleUserStatus = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    user.isVerified = !user.isVerified;
    await user.save({ validateBeforeSave: false });

    res.status(200).json({
      message: `User ${user.isVerified ? "activated" : "deactivated"} successfully`,
      isVerified: user.isVerified,
    });
  } catch (err) {
    console.error("Toggle Status Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findByIdAndDelete(userId);
    if (!user) return res.status(404).json({ error: "User not found" });
    res.status(200).json({ message: "User deleted successfully" });
  } catch (err) {
    console.error("Delete User Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};
