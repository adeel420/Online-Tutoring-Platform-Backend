const {
  Verification_Email_Template,
  Welcome_Email_Template,
  Teacher_Pending_Template,
  Admin_Teacher_Notification_Template,
  Teacher_Approved_Template,
  Teacher_Rejected_Template,
} = require("../utils/emailTemplate");
const transporter = require("./nodemailer");
require("dotenv").config();

const ADMIN_EMAIL = process.env.ADMIN_EMAIL;
const FROM = '"TutorHub" <' + process.env.EMAIL_USER + ">";

// Send OTP verification code to user
const sendVerificationCode = async (email, verificationCode) => {
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: "Verify Your Email — TutorHub",
    html: Verification_Email_Template.replace("{verificationCode}", verificationCode),
  });
};

// Send welcome email after email is verified
const welcomeCode = async (email, name) => {
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: "Welcome to TutorHub! 🎉",
    html: Welcome_Email_Template.replace("{name}", name),
  });
};

// Send pending approval email to teacher after signup
const sendTeacherPendingEmail = async (email, name) => {
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: "Your TutorHub Account is Under Review ⏳",
    html: Teacher_Pending_Template.replace("{name}", name),
  });
};

// Send notification to admin when a teacher registers
const sendAdminTeacherNotification = async ({ name, email, phone }) => {
  const date = new Date().toLocaleString("en-PK", { timeZone: "Asia/Karachi" });
  await transporter.sendMail({
    from: FROM,
    to: ADMIN_EMAIL,
    subject: `New Teacher Registration: ${name} — TutorHub`,
    html: Admin_Teacher_Notification_Template
      .replace("{name}", name)
      .replace("{email}", email)
      .replace("{phone}", phone)
      .replace("{date}", date),
  });
};

// Send approval email to teacher when admin approves their account
const sendTeacherApprovedEmail = async (email, name) => {
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: "Your TutorHub Account Has Been Approved! 🎉",
    html: Teacher_Approved_Template.replace("{name}", name),
  });
};

// Send rejection email to teacher when admin rejects their account
const sendTeacherRejectedEmail = async (email, name) => {
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: "Your TutorHub Application Has Been Rejected",
    html: Teacher_Rejected_Template.replace("{name}", name),
  });
};

module.exports = {
  sendVerificationCode,
  welcomeCode,
  sendTeacherPendingEmail,
  sendAdminTeacherNotification,
  sendTeacherApprovedEmail,
  sendTeacherRejectedEmail,
};
